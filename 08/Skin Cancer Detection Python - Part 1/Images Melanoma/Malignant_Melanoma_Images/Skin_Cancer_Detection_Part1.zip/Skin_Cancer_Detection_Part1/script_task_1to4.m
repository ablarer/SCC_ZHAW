% This script does the following:
% 1) Define the path to the test image(s) 
% 2) Defines the input parameters for the sub-functions to be called
% 3) Define arrays for the asymmetry and colour score for nevi and melanoma
% 4) Runs a parfor (see MATLAB Parallel Computing Toolbox) loop,
%    calling the subfunctions calculate_border.m, calculate_polar_coordinates.m,
%    calculate_asymmetry.m,calculate_color.m. 
%    (optional: these subfunctions can be summarized in asubfunction calculate_all.m)
%
% Date: November, 2, 2017; RK

clear all
close all

%% 1) Define paths
path = '.';
img ='B496a.png';
path_img = [path '\' img];
fprintf('Processed Picture: %s\n',img);

%% 2) Defines the input parameters for the sub-functions to be called
crop_factor_nevi = 0.01;        % 1% of the edges of nevi images is cut away
crop_factor_melanoma1 = 0.1;    % 10% of the edges of nevi images is cut away
sigma = 5;                      % sigma for imgaussfilt.m 
rel_diff = 0.1;                 % the relative difference between radii to increase the SFA index for the asymmetry calculation
sfa_thresh = 140;               % SFA index value used for the asymmetry score 
color_threshold = 0.01;         % trheshold for the the color calculation
plot_image = 0;                 % if set to 1, plots are generated

color_table = zeros(6,3);         % this color table defines the specific colors relevant for the color score
color_table(1,:) = [255 255 255]; % white
color_table(2,:) = [204 51 51];   % red
color_table(3,:) = [153 102 0];   % light brown
color_table(4,:) = [51 0 0];      % dark brown
color_table(5,:) = [51 153 255];  % blue gray
color_table(6,:) = [0 0 0];       % black

%% 3) Define arrays for the SFA index, asymmetry score, colour score
%     and variance in RGB for nevi and melanoma

num_pic_nevi = 10;
%num_pic_nevi = length(NEVI);
sfa_all_nevi=NaN(num_pic_nevi, 1);
asymmetry_all_nevi=NaN(num_pic_nevi, 1);
color_score_all_nevi=NaN(num_pic_nevi, 1);
variance_all_nevi=NaN(num_pic_nevi, 3);

num_pic_melanoma1 = 10;
%num_pic_melanoma1 = length(MELANOMA1);
sfa_all_melanoma1=NaN(num_pic_melanoma1, 1);
asymmetry_all_melanoma1=NaN(num_pic_melanoma1, 1);
color_score_all_melanoma1=NaN(num_pic_melanoma1, 1);
variance_all_melanoma1=NaN(num_pic_melanoma1, 3);



%% 4) Runs a parfor (see MATLAB Parallel Computing Toolbox) loop,
%     calling the subfunctions calculate_border.m, calculate_polar_coordinates.m,
%     calculate_asymmetry.m,calculate_color.m. 
%     (optional: these subfunctions can be summarized in a subfunction calculate_all.m)
%     The results are written to the arrays sfa_all_nevi,
%     asymmetry_all_nevi, color_score_all_nevi, variance_all_nevi.


parfor k=1:1 
    
    % Read Image and calculate border of lesion
    [cropped_img_cl,cropped_img_gs,cropped_img_mask,border] = calculate_border_task1(path_img, crop_factor_melanoma1, sigma);
  
    
    %Calculate the centroid (center of mass) and bounding box    
    s = regionprops(uint8(cropped_img_mask), cropped_img_gs, {'Centroid','PixelValues','BoundingBox','MajorAxisLength','MinorAxisLength','Orientation'});

    %Calculate polar coordinates (radii and angles), sort in ascending
    %order
    [r, alpha, ~, ~, ~, r_bin, alpha_bin] = ...
    calculate_polar_coordinates_task4(s(1).Centroid(1), s(1).Centroid(2), border);
    
    %Calculate asymmetry score and the sum of the SFA index divided by its
    %length (360)
    [sfa,~,ind_major_axis,~,ind_minor_axis,asymmetry] = ...
    calculate_asymmetry_task4(r_bin,rel_diff, sfa_thresh);

    %Calculate the color score and the variance of all the pixels inside
    %the lesion in the R,G,B channels
    [color_score, ~, ~ ,variance] = ...
    calculate_color_task3(cropped_img_cl,cropped_img_mask,color_table,color_threshold,plot_image);
    
    %Display results
    fprintf('asymmetry score:%e\n',asymmetry);
    fprintf('color score:%e\n',color_score);
    fprintf('variance: %4.2f, %4.2f. %4.2f \n',variance(1),variance(2),variance(3));

    %Write results into arrays (sfa is summed up and devided by its length
    %360)
    sfa_all_melanoma1(k)=sum(sfa)/length(sfa);
    asymmetry_all_melanoma1(k)=asymmetry;
    color_score_all_melanoma1(k)=color_score;
    variance_all_melanoma1(k,:)=variance;

end



